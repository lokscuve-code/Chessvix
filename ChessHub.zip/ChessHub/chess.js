// تهيئة لوحة الشطرنج
const board = document.getElementById('board');
const gameStatus = document.getElementById('gameStatus');
let selectedSquare = null;
let gameBoard = [];

// رموز القطع
const pieces = {
    'wK': '♔', 'wQ': '♕', 'wR': '♖', 'wB': '♗', 'wN': '♘', 'wp': '♙',
    'bK': '♚', 'bQ': '♛', 'bR': '♜', 'bB': '♝', 'bN': '♞', 'bp': '♟'
};

// تهيئة اللوحة بالقطع
function initializeBoard() {
    gameBoard = [
        ['br', 'bn', 'bb', 'bq', 'bk', 'bb', 'bn', 'br'],
        ['bp', 'bp', 'bp', 'bp', 'bp', 'bp', 'bp', 'bp'],
        [null, null, null, null, null, null, null, null],
        [null, null, null, null, null, null, null, null],
        [null, null, null, null, null, null, null, null],
        [null, null, null, null, null, null, null, null],
        ['wp', 'wp', 'wp', 'wp', 'wp', 'wp', 'wp', 'wp'],
        ['wr', 'wn', 'wb', 'wq', 'wk', 'wb', 'wn', 'wr']
    ];
    renderBoard();
}

// رسم اللوحة
function renderBoard() {
    board.innerHTML = '';
    for (let row = 0; row < 8; row++) {
        for (let col = 0; col < 8; col++) {
            const square = document.createElement('div');
            square.className = 'square';
            square.dataset.row = row;
            square.dataset.col = col;
            
            const piece = gameBoard[row][col];
            if (piece) {
                const pieceKey = piece[0] + piece[1].toUpperCase();
                square.textContent = pieces[pieceKey] || piece;
            }
            
            square.addEventListener('click', () => handleSquareClick(row, col));
            board.appendChild(square);
        }
    }
}

// معالجة النقر على الخانة
function handleSquareClick(row, col) {
    if (selectedSquare === null) {
        // اختيار قطعة
        if (gameBoard[row][col] !== null) {
            selectedSquare = {row, col};
            gameStatus.textContent = `تم اختيار قطعة في (${row}, ${col})`;
        }
    } else {
        // تحريك القطعة
        const fromRow = selectedSquare.row;
        const fromCol = selectedSquare.col;
        const piece = gameBoard[fromRow][fromCol];
        
        // تحريك بسيط (بدون التحقق من الحركات القانونية حالياً)
        if ((row !== fromRow || col !== fromCol) && isValidMove(piece, fromRow, fromCol, row, col)) {
            gameBoard[row][col] = piece;
            gameBoard[fromRow][fromCol] = null;
            gameStatus.textContent = `تم تحريك القطعة من (${fromRow}, ${fromCol}) إلى (${row}, ${col})`;
        } else {
            gameStatus.textContent = 'حركة غير صحيحة!';
        }
        
        selectedSquare = null;
        renderBoard();
    }
}

// التحقق من صحة الحركة
function isValidMove(piece, fromRow, fromCol, toRow, toCol) {
    const type = piece[1];
    const rowDiff = Math.abs(toRow - fromRow);
    const colDiff = Math.abs(toCol - fromCol);
    
    switch(type) {
        case 'p': // جندي
            return (toRow - fromRow === 1 || (fromRow === 6 && toRow === 4)) && colDiff === 0;
        case 'n': // حصان
            return (rowDiff === 2 && colDiff === 1) || (rowDiff === 1 && colDiff === 2);
        case 'b': // فيل
            return rowDiff === colDiff;
        case 'r': // رخ
            return toRow === fromRow || toCol === fromCol;
        case 'q': // ملكة
            return toRow === fromRow || toCol === fromCol || rowDiff === colDiff;
        case 'k': // ملك
            return rowDiff <= 1 && colDiff <= 1;
        default:
            return false;
    }
}

// إعادة تعيين اللعبة
function resetGame() {
    initializeBoard();
    selectedSquare = null;
    gameStatus.textContent = 'تم إعادة تعيين اللعبة. ابدأ من جديد!';
}

// بدء اللعبة
initializeBoard();
